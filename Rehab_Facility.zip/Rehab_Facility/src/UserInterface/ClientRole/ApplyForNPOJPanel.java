/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.ClientRole;

import Business.Application.Application;
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Organization.ClientOrganization;
import Business.Organization.ExaminerOrganization;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import java.awt.CardLayout;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author keert
 */
public class ApplyForNPOJPanel extends javax.swing.JPanel {

    /**
     * Creates new form ApplyForNPOJPanel
     */
    
    private JPanel userProcessContainer;
    private EcoSystem system;
    private UserAccount useraccount;
    private Enterprise enterprise;
    private ClientOrganization corg;
    private Network network;

    
    public ApplyForNPOJPanel(JPanel userProcessContainer, UserAccount account, Enterprise enterprise, ClientOrganization corg, Network network, EcoSystem system) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.system = system;
        this.useraccount = account;
        this.corg = corg;
        this.enterprise = enterprise;
        this.network = network;
        
        if(useraccount.getApplication()==null) {
            useraccount.setApplication(new Application());
            updateBtn.setEnabled(false);
        }
        else {
            displayInfo(useraccount);
        }
        
        if(useraccount.getApplication().getStatus()==null) {
            valueLbl.setText("Pending...");
        }
        else {
        valueLbl.setText(useraccount.getApplication().getStatus());
        }
        
        /*if(useraccount.getApplication().getStatus().equals("Application Approved")){
            applyBtn.setEnabled(false);
            updateBtn.setEnabled(false);
        }
        else*/ {
            applyBtn.setEnabled(true);
            updateBtn.setEnabled(true);
        }
    }

    private void displayInfo (UserAccount useraccount) {
       
        fnameTxt.setText(useraccount.getApplication().getFirstName());
        fnameTxt.setEnabled(false);
        lnameTxt.setText(useraccount.getApplication().getLastName());
        lnameTxt.setEnabled(false);
        mnameTxt.setText(useraccount.getApplication().getMiddleName());
        mnameTxt.setEnabled(false);
        aline1Txt.setText(useraccount.getApplication().getAddrLine1());
        aline1Txt.setEnabled(false);
        aline2Txt.setText(useraccount.getApplication().getAddrLine2());
        aline2Txt.setEnabled(false);
        cityTxt.setText(useraccount.getApplication().getCity());
        cityTxt.setEnabled(false);
        stateTxt.setText(useraccount.getApplication().getState());
        stateTxt.setEnabled(false);
        problemDescriptionTxt.setText(useraccount.getApplication().getProblemDesc());
        problemDescriptionTxt.setEnabled(false);
        incomeTxt.setText(convertInteger(useraccount.getApplication().getIncome()));
        incomeTxt.setEnabled(false);
        zipTxt.setText(convertInteger(useraccount.getApplication().getZipcode()));
        zipTxt.setEnabled(false);
//        numberTxt.setText(convertLong(useraccount.getApplication().getNumber()));
        ImageIcon icon = new ImageIcon((useraccount.getApplication().getPicturePath()));
        icon.setImage(icon.getImage().getScaledInstance(162, 102, Image.SCALE_DEFAULT));
        imageLbl.setIcon(icon);
        uploadBtn.setEnabled(false);
        
    }
    
    public static String convertInteger(int i) {
        return Integer.toString(i);
    }
    
    public static String convertLong(long i) {
        return Long.toString(i);
    }
    
    private void updateApplication() {
        useraccount.getApplication().setFirstName(fnameTxt.getText());
        useraccount.getApplication().setMiddleName(mnameTxt.getText());
        useraccount.getApplication().setLastName(lnameTxt.getText());
        useraccount.getApplication().setAddrLine1(aline1Txt.getText());
        useraccount.getApplication().setAddrLine2(aline2Txt.getText());
        useraccount.getApplication().setCity(cityTxt.getText());
        useraccount.getApplication().setState(stateTxt.getText());
        useraccount.getApplication().setProblemDesc(problemDescriptionTxt.getText());
        useraccount.getApplication().setApplicant(useraccount);
//        ImageIcon icon = new ImageIcon((useraccount.getApplication().getPicturePath()));
//        icon.setImage(icon.getImage().getScaledInstance(162, 102, Image.SCALE_DEFAULT));
//        imageLbl.setIcon(icon);
        
        try {
            int income = Integer.parseInt(incomeTxt.getText());
            useraccount.getApplication().setIncome(income);
        }
        catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Income must be a number.");
            return;
        }
        
                try {
            int income = Integer.parseInt(incomeTxt.getText());
            useraccount.getApplication().setIncome(income);
        }
        catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Income must be a number.");
            return;
        }


        JOptionPane.showMessageDialog(null,"Application Successfully Submitted");
        
        fnameTxt.setText("");
        lnameTxt.setText("");
        mnameTxt.setText("");
        aline1Txt.setText("");
        aline2Txt.setText("");
        cityTxt.setText("");
        stateTxt.setText("");
        zipTxt.setText("");
        problemDescriptionTxt.setText("");
        incomeTxt.setText("");

        imageLbl.setText("");
        
        fnameTxt.setEditable(true);
        lnameTxt.setEditable(true);
        mnameTxt.setEditable(true);
        aline1Txt.setEditable(true);
        aline2Txt.setEditable(true);
        cityTxt.setEditable(true);
        stateTxt.setEditable(true);
        zipTxt.setEditable(true);
        incomeTxt.setEditable(true);
        problemDescriptionTxt.setEditable(true);
        uploadBtn.setEnabled(true);

    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        fnameTxt = new javax.swing.JTextField();
        mnameTxt = new javax.swing.JTextField();
        lnameTxt = new javax.swing.JTextField();
        aline1Txt = new javax.swing.JTextField();
        aline2Txt = new javax.swing.JTextField();
        cityTxt = new javax.swing.JTextField();
        stateTxt = new javax.swing.JTextField();
        zipTxt = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        incomeTxt = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        problemDescriptionTxt = new javax.swing.JTextField();
        applyBtn = new javax.swing.JButton();
        backBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        valueLbl = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        uploadBtn = new javax.swing.JButton();
        imageLbl = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        backBtn1 = new javax.swing.JButton();
        backBtn2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("First Name");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 150, 30));

        jLabel3.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 0, 51));
        jLabel3.setText("Middle Name");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 190, 170, 30));

        jLabel4.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 0, 0));
        jLabel4.setText("Last Name");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 190, 125, 30));

        jLabel5.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 0, 0));
        jLabel5.setText("Address Line 1");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 180, 30));

        jLabel6.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 0, 0));
        jLabel6.setText("Address Line 2");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 180, 30));

        jLabel7.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 0, 0));
        jLabel7.setText("City");
        add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 70, 30));

        jLabel8.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 0, 0));
        jLabel8.setText("State");
        add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 340, 90, 30));

        jLabel9.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 0, 0));
        jLabel9.setText("Zip Code");
        add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 340, 120, 30));

        fnameTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        fnameTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fnameTxtActionPerformed(evt);
            }
        });
        add(fnameTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 150, 30));

        mnameTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        add(mnameTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 190, 130, 30));

        lnameTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lnameTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lnameTxtActionPerformed(evt);
            }
        });
        add(lnameTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 190, 160, 30));
        add(aline1Txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 240, 570, 30));
        add(aline2Txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 280, 570, 30));

        cityTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        add(cityTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 340, 150, 30));

        stateTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        add(stateTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 340, 150, 30));

        zipTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        add(zipTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 340, 150, 30));

        jLabel10.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 0, 0));
        jLabel10.setText("Annual Income      $");
        add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 220, 30));

        incomeTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        add(incomeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 390, 150, 30));

        jLabel12.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(204, 0, 0));
        jLabel12.setText("Problem Description");
        add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 440, 250, 30));

        problemDescriptionTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                problemDescriptionTxtActionPerformed(evt);
            }
        });
        add(problemDescriptionTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 480, 738, 30));

        applyBtn.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        applyBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/ClientRole/btn apply.jpg"))); // NOI18N
        applyBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        applyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                applyBtnActionPerformed(evt);
            }
        });
        add(applyBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 540, 80, 30));

        backBtn.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        backBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/ClientRole/btn back.jpg"))); // NOI18N
        backBtn.setText("<<Back");
        backBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });
        add(backBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(-100, 740, 90, 30));

        updateBtn.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        updateBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/ClientRole/btn update.jpg"))); // NOI18N
        updateBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });
        add(updateBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 540, 100, 30));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setText("Status");
        add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 120, 40));

        valueLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        valueLbl.setForeground(new java.awt.Color(204, 0, 0));
        add(valueLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 259, 40));

        jLabel14.setFont(new java.awt.Font("Stencil", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(204, 0, 51));
        jLabel14.setText("Upload Supporting Documents");
        add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 540, 380, 30));

        uploadBtn.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        uploadBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/ClientRole/btn upload.jpg"))); // NOI18N
        uploadBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        uploadBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadBtnActionPerformed(evt);
            }
        });
        add(uploadBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 540, 90, 30));
        add(imageLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 170, 340, 360));

        jPanel3.setBackground(new java.awt.Color(153, 153, 255));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Stencil", 1, 30)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Apply for npo");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1331, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(56, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, -1));

        backBtn1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        backBtn1.setText("<<Back");
        backBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtn1ActionPerformed(evt);
            }
        });
        add(backBtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        backBtn2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        backBtn2.setText("<<Back");
        backBtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtn2ActionPerformed(evt);
            }
        });
        add(backBtn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/UserInterface/ClientRole/btn back.jpg"))); // NOI18N
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 540, 100, 30));
    }// </editor-fold>//GEN-END:initComponents

    private void fnameTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnameTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fnameTxtActionPerformed

    private void problemDescriptionTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_problemDescriptionTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_problemDescriptionTxtActionPerformed

    private void applyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_applyBtnActionPerformed
        // TODO add your handling code here:
        Organization org = null;
        for(Enterprise e : network.getEnterpriseDirectory().getEnterpriseList()) {
            for (Organization o : e.getOrganizationDirectory().getOrganizationList()){
                if (o instanceof ExaminerOrganization){
                    org = o;
                    break;
                }
            }
            if (org!=null){
                if(org.getApplicationDirectory().getApplicationList().contains(useraccount.getApplication())) {
                    int i = org.getApplicationDirectory().getApplicationList().indexOf(useraccount.getApplication());
                    updateApplication();
                    org.getApplicationDirectory().getApplicationList().set(i, useraccount.getApplication());
                }
                else {
                    updateApplication();
                    org.getApplicationDirectory().getApplicationList().add(useraccount.getApplication());
                }
                break;
            }
        }
    }//GEN-LAST:event_applyBtnActionPerformed

    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnActionPerformed
        // TODO add your handling code here:
        this.userProcessContainer.remove(this);
        CardLayout layout= (CardLayout)this.userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_backBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        // TODO add your handling code here:
        UpdateApplicationJPanel uajp =new UpdateApplicationJPanel (userProcessContainer,useraccount,corg, enterprise,network,system);
        userProcessContainer.add("UpdateApplicationJPanel", uajp);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer); 
    }//GEN-LAST:event_updateBtnActionPerformed

    private void lnameTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lnameTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lnameTxtActionPerformed

    private void uploadBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadBtnActionPerformed
        // TODO add your handling code here:
        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        useraccount.getApplication().setPicturePath(chooser.getSelectedFile().getAbsolutePath());
        ImageIcon icon = new ImageIcon(useraccount.getApplication().getPicturePath());
        icon.setImage(icon.getImage().getScaledInstance(162, 102, Image.SCALE_DEFAULT));
        imageLbl.setIcon(icon);
        
       
    }//GEN-LAST:event_uploadBtnActionPerformed

    private void backBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtn1ActionPerformed
        // TODO add your handling code here:
        this.userProcessContainer.remove(this);
        CardLayout layout= (CardLayout)this.userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_backBtn1ActionPerformed

    private void backBtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtn2ActionPerformed
        // TODO add your handling code here:
        this.userProcessContainer.remove(this);
        CardLayout layout= (CardLayout)this.userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_backBtn2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         this.userProcessContainer.remove(this);
        CardLayout layout= (CardLayout)this.userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField aline1Txt;
    private javax.swing.JTextField aline2Txt;
    private javax.swing.JButton applyBtn;
    private javax.swing.JButton backBtn;
    private javax.swing.JButton backBtn1;
    private javax.swing.JButton backBtn2;
    private javax.swing.JTextField cityTxt;
    private javax.swing.JTextField fnameTxt;
    private javax.swing.JLabel imageLbl;
    private javax.swing.JTextField incomeTxt;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField lnameTxt;
    private javax.swing.JTextField mnameTxt;
    private javax.swing.JTextField problemDescriptionTxt;
    private javax.swing.JTextField stateTxt;
    private javax.swing.JButton updateBtn;
    private javax.swing.JButton uploadBtn;
    private javax.swing.JLabel valueLbl;
    private javax.swing.JTextField zipTxt;
    // End of variables declaration//GEN-END:variables
}
