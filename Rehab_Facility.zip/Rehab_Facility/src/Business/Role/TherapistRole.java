/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import static Business.Enterprise.Enterprise.EnterpriseType.Rehab;
import static Business.Enterprise.Enterprise.EnterpriseType.NPO;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.TherapistRole.TherapistWorkAreaJPanel;
import UserInterface.NPOTherapist.NPOTherapistWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author keert
 */
public class TherapistRole extends Role{
    public TherapistRole()
    {
                super(Role.RoleType.Therapist.getValue());
    }
    
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, Network network, EcoSystem business) {
        
        if(enterprise.getEnterpriseType().equals(Rehab)) {
            return new TherapistWorkAreaJPanel(userProcessContainer, account, enterprise);
        }
        else if (enterprise.getEnterpriseType().equals(NPO))
        {
            return new NPOTherapistWorkAreaJPanel (userProcessContainer, account, enterprise);
        }
       return null;
}
 
}
